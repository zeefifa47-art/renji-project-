# Setup Renji — kunci & anti-tamper

## 1. Keystore untuk build (GitHub Actions)
```
keytool -genkeypair -v -keystore renji.keystore -alias renji -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 renji.keystore   # hasilnya -> secret RENJI_KEYSTORE_B64 di GitHub
```
Isi juga secret `RENJI_KEYSTORE_PASS`, `RENJI_KEY_ALIAS`, `RENJI_KEY_PASS` di
Settings → Secrets and variables → Actions.

## 2. Ambil SHA-256 signing certificate (untuk IntegrityGate)
Setelah build APK release pertama kali:
```
keytool -printcert -jarfile app-release.apk
```
Salin baris `SHA256:`, hapus titik duanya, tempel ke
`IntegrityGate.EXPECTED_CERT_SHA256` (huruf kecil semua), lalu build ulang.

## 3. Hash kredit
```
python tools/credit_hash.py "Renji by @cray"
```
Tempel hasilnya ke `IntegrityGate.EXPECTED_CREDIT_HASH`.

Kalau nanti ada yang mem-fork lalu mengubah `Credit.TAG` (misal tetap
mengklaim "@cray" tapi isinya diubah), hash-nya tidak akan cocok lagi ->
`IntegrityGate.syncState()` mengembalikan `false` -> notifikasi muncul
(dengan delay acak, lihat `NotifyWorker.kt`, supaya tidak gampang
dikorelasikan ke baris kode mana) yang mengarahkan pengguna ke saluran
WhatsApp resmi untuk ambil APK yang benar.

## Saluran resmi
Link saluran WA ada di `Credit.WA_CHANNEL` dan dipakai di dua tempat:
tombol "Saluran WhatsApp resmi" di layar utama, dan sebagai tujuan
notifikasi kalau integritas APK tidak cocok.

## Batasan yang jujur perlu kamu tahu
- Tidak ada proteksi APK yang 100% tidak bisa di-crack. Ini
  **memperberat**, bukan menghilangkan risiko sepenuhnya.
- Signature check paling kuat karena tidak bergantung string apa pun —
  orang yang build ulang dengan keystore lain otomatis gagal cocok.
- `EXPECTED_CERT_SHA256` dan `EXPECTED_CREDIT_HASH` dikosongkan dulu di
  kode supaya build awal tidak langsung mengunci diri sendiri. Isi
  keduanya setelah APK release pertama berhasil dibuat (langkah 2–3).
