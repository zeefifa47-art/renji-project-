"""
Cetak SHA-256 dari string kredit resmi, untuk ditempel ke
IntegrityGate.EXPECTED_CREDIT_HASH. Dan cetak SHA-256 dari signing
certificate kamu, untuk IntegrityGate.EXPECTED_CERT_SHA256
(lihat README_SIGNING.md cara ambil signing cert hash).

    python credit_hash.py "Renji by @cray"
"""
import sys, hashlib

text = sys.argv[1] if len(sys.argv) > 1 else "Renji by @cray"
print(hashlib.sha256(text.encode()).hexdigest())
