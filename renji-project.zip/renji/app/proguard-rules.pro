# R8 full mode mengacak nama kelas/fungsi internal — ini yang membuat
# IntegrityGate/NotifyWorker sulit dibaca langsung dari APK hasil decompile.
-repackageclasses ''
-allowaccessmodification
-overloadaggressively

# Jangan obfuscate entry point Android standar
-keep class com.renji.app.ui.MainActivity

# Hilangkan log debug di build release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}
