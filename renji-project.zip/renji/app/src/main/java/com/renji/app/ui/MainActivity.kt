package com.renji.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.renji.app.R
import com.renji.app.core.NotifyWorker

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.btnBoost)?.setOnClickListener {
            NotifyWorker.onUserAction(this)
            // TODO: panggil fitur booster (Shizuku + ANGLE) di sini
        }

        findViewById<android.view.View>(R.id.btnChannel)?.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(com.renji.app.core.Credit.WA_CHANNEL))
            )
        }
    }
}
