package com.renji.app.core

/**
 * Satu-satunya tempat teks kredit ditulis polos. Kalau ini diubah,
 * hash-nya (dicek di IntegrityGate) ikut berubah.
 */
internal object Credit {
    const val TAG = "Renji by @cray"
    const val WA_CHANNEL = "https://whatsapp.com/channel/0029VbDqrP99Bb5uh7zoYr1M"
}
