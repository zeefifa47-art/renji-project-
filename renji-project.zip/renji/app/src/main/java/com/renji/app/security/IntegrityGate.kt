package com.renji.app.security

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Nama file & fungsi sengaja dibuat generik ("sync", "prefs", "cfg") supaya
 * tidak langsung terlihat sebagai pengecekan anti-tamper saat APK dibongkar.
 *
 * CATATAN JUJUR: ini memperberat orang yang mau mem-forge kredit/signature,
 * bukan membuatnya 100% mustahil. Siapa pun yang punya waktu & skill reverse
 * engineering tetap bisa mem-patch ini. Yang membuatnya sulit adalah
 * kombinasi: R8 minify, nama disamarkan, logika terpecah, dan trigger
 * notifikasi yang tidak langsung (lihat NotifyWorker).
 */
internal object IntegrityGate {

    // Tempel hash SHA-256 dari signing certificate kamu sendiri di sini
    // (cara ambilnya ada di README_SIGNING.md). Kosong = cek dilewati saat dev.
    private const val EXPECTED_CERT_SHA256 = ""

    // Hash SHA-256 dari string kredit resmi, bukan teksnya langsung,
    // supaya "@cray" tidak muncul polos di hasil decompile string table.
    private const val EXPECTED_CREDIT_HASH = "" // diisi dari CreditHashGen

    fun syncState(ctx: Context): Boolean {
        val certOk = EXPECTED_CERT_SHA256.isEmpty() || certMatches(ctx)
        val creditOk = EXPECTED_CREDIT_HASH.isEmpty() || creditMatches()
        return certOk && creditOk
    }

    private fun certMatches(ctx: Context): Boolean = try {
        val sig = currentSignature(ctx) ?: return false
        val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
        val hex = digest.joinToString("") { "%02x".format(it) }
        hex.equals(EXPECTED_CERT_SHA256, ignoreCase = true)
    } catch (e: Exception) {
        false
    }

    private fun currentSignature(ctx: Context): Signature? {
        val pm = ctx.packageManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            info.signatures?.firstOrNull()
        }
    }

    private fun creditMatches(): Boolean {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(com.renji.app.core.Credit.TAG.toByteArray())
        val hex = digest.joinToString("") { "%02x".format(it) }
        return hex.equals(EXPECTED_CREDIT_HASH, ignoreCase = true)
    }
}
