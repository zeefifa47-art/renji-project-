package com.renji.app.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.renji.app.R
import com.renji.app.security.IntegrityGate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Dipanggil dari beberapa titik "biasa" di aplikasi (buka halaman, pindah tab,
 * dsb) lewat nama fungsi generik supaya tidak ada satu titik mencolok yang
 * langsung menunjuk ke pengecekan integritas.
 */
internal object NotifyWorker {

    fun onUserAction(ctx: Context) {
        // Delay acak 1.5–6 menit & hanya jalan sebagian kecil pemanggilan,
        // supaya tidak gampang dikorelasikan ke baris kode mana yang memicu.
        if (Random.nextInt(100) >= 12) return

        CoroutineScope(Dispatchers.Default).launch {
            delay(Random.nextLong(90_000L, 360_000L))
            if (!IntegrityGate.syncState(ctx)) {
                postNotice(ctx)
            }
        }
    }

    private fun postNotice(ctx: Context) {
        val channelId = "renji_updates"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Pembaruan", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        val channelIntent = android.app.PendingIntent.getActivity(
            ctx, 0,
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(Credit.WA_CHANNEL)),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(R.drawable.ic_stat_renji)
            .setContentTitle("Versi tidak dikenali")
            .setContentText("Ambil APK resmi #cray lewat saluran WA.")
            .setContentIntent(channelIntent)
            .setAutoCancel(true)
            .build()

        nm.notify(4471, notif)
    }
}
